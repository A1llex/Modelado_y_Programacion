Alex Gerardo Fernández Aguilar
Luis Erick Montes Garcia

Procesador Digital De Imagenes 

Para Funcionar hay que abrir Procesamiento de Archihvos o bien en src Vista 
que sera la interfz en html para iniciar el programa.

para Ejecutar las pruebas es necesario estar en la ruta de pruebas y en la consola usar los siguientes comandos

nmp install --save-dev mocha
nmp init
nmp test para ver la ejecucion de la pruebas